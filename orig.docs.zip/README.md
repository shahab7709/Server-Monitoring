# Server Monitoring Platform — Architecture Package

This repository currently contains the **architecture/design phase**, not a runnable implementation. See `docs/architecture.md` for the HLD/LLD and the accepted ADRs for decisions to implement in Go.

## Target implementation
- Go API + Go worker + Go simulator
- TimescaleDB, NATS JetStream, Docker Compose
- Single-file HTML dashboard served by Go
- Go smoke tests and k6 load tests

## Acceptance gates before marking complete
- `docker compose up --build` starts all components and exposes port 8080.
- A configurable number of devices can backfill >= 3 days and send 1 sample/sec.
- Metrics accepted only after durable publication and available after DB commit.
- One-year graph meets p95 end-to-end <1s on declared hardware and workload.
- Smoke and load tests are runnable from the repository.

**Status:** design only; implementation and measured performance pending.
