module example.com/server-monitoring

go 1.23.2
